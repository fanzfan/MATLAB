B.mat  mean A * Hp + B * Hs = 0;
col_order mean Column Order
H1.mat mean H1 = 
HN.mat mean HN = P * B 
H.mat  mean Generate Check Matrix
HG.mat mean Hp = G * Hs
L1.mat mean L1 = L ^ -1
U1.mat mean U1 = U ^ -1
L.mat  mean L * U * Hp = P * B * Hs
U.mat  mean L * U * Hp = P * B * Hs
P.mat  mean L * U * Hp = P * B * Hs

